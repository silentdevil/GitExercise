import java.util.*;
public class Pair {
	
	private int x = -1,y = -1;
	private static Scanner scan;
	static {
		scan = new Scanner(System.in);
	}
	public Pair(){
		//Scanner scan = new Scanner(System.in);
		String str = "Please enter a valid input";
		String X,Y;
		do {
			System.out.print("Enter a value for x : ");
			X = scan.nextLine();
			if(isNumeric(X) && !X.isEmpty()){
				x = Integer.parseInt(X);
				do {
					System.out.print("Enter a value for Y : ");
					Y = scan.nextLine();
					if(isNumeric(Y) && !Y.isEmpty()){
						y = Integer.parseInt(Y);
						str = "";
					}
				}while(Y.isEmpty());
			}
		} while(X.isEmpty());
		
		System.out.println(str);
	}
	public int getX(){
		return x;
	}
	
	public int getY(){
		return y;
	}
	
	private boolean isNumeric(String s){ // can be public static
		char[] str = s.toCharArray();
		for(char a : str){
			if(a < '0' || a > '9')
				return false;
			//continue;
		}
		return true;	
	}
	
}