public class Pattern {
	public static int occurencies(String one, String two){
		int counter = 0;
		if(one.contains(two)) {
			boolean match = false;
			char[] a = one.toCharArray();
			char[] b = two.toCharArray();
			if(two.isEmpty()){
				if(one.isEmpty())
					counter = 1;
			}
			else {
				for(int k = 0; k < a.length; k++) {
					if(b[0] == a[k] && (a.length-k) >= b.length){
						match = true;
						for(int l = 1;l<b.length;l++){
							if(b[l] == a[k+l])
								continue;
							else{
								match = false;
								break;
							}
						}
						if(match == true)
							counter++;
					}
				}	
			 }
		}
		return counter;
	}
}