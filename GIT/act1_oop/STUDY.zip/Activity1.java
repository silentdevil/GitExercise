import java.util.*;

public class Activity1 {
	private String[][] stringGrid;
	private int x,y;
	private static Scanner scan;
	Pair p;
	
	public static void main(String[] args) {
		Activity1 a = new Activity1();
		a.create();
		String val = "";
		scan = new Scanner(System.in);
		while(!val.equals("EXIT")){
			System.out.print("What do you want to do? [PRINT, EDIT, RECREATE, SEARCH, EXIT]");
			val = (scan.nextLine().toUpperCase());
			switch(val){
				case "PRINT": a.print();break;
				case "EDIT": a.edit();break;
				case "RECREATE": a.create();break;
				case "SEARCH": a.search();break;
				case "EXIT": break;
				default: System.out.println("Please enter a valid input");
			}
		}
	}
	
	private void search(){
		int counter = 0;
		System.out.print("Search: ");
		String str = scan.nextLine();
			for(int i=0;i<x;i++) {
				for(int j=0;j<y;j++){
					int occurence = Pattern.occurencies(stringGrid[i][j], str);
					if(occurence > 0) {
						counter += occurence;
						String address = "(" + i + "," + j + ")";
						System.out.println(address + " with "+ occurence + " occurence/s");
					}
				}
			}
			System.out.println(str +" has "+counter+" occurence/s");
	}
	
	private void create() {
		p = new Pair();
		x = p.getX(); y = p.getY();
		if(p.getX() > -1 || p.getY() > -1) {
			stringGrid = new String[x][y];
			for(int i=0;i<x;i++) 
				for(int j=0;j<y;j++)
					 stringGrid[i][j] = randomizeChar();
			print();
		}	
	}
	
	private void print() {
		int counter = 1;
		for(int i=0;i<x;i++) {
			for(int j=0;j<y;j++){
				System.out.print("\t"+counter+stringGrid[i][j]+"\t");
				counter++;
			}
			System.out.println();
		}
	}
	
	private String randomizeChar() {
		Random r = new Random();
		int len = r.nextInt(5) + 1;
		char[] str = new char[len];
		for(int i=0;i<len;i++)
			str[i] = (char) r.nextInt((int)Character.MAX_VALUE);
		return String.valueOf(str);
	}
	
	private void edit()
	{
		p = new Pair();
		int a = p.getX(); int b = p.getY();
		if(a > x - 1 || b > y - 1)
			System.out.println("Value greater than the range");
		else if(p.getX() > -1 && p.getY() > -1){
			System.out.println("Your new word: ");
			String str = scan.nextLine();
			if(str!=null)
				stringGrid[a][b] = str;
			print();
		}
	}
}
